package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static butt.droid.awtRobot.AWTRobot _c3po = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static anywheresoftware.b4a.objects.SocketWrapper _client = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public static boolean _connected = false;
public static anywheresoftware.b4a.objects.Timer _timer1 = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lblip = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lblstatus = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _imageview1 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 26;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 27;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 28;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 30;BA.debugLine="timer1.Initialize(\"timer1\",1000)";
_timer1.Initialize(ba,"timer1",(long) (1000));
 //BA.debugLineNum = 31;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 34;BA.debugLine="server.Initialize(\"51042\",\"server\")";
_server.Initialize(ba,(int)(Double.parseDouble("51042")),"server");
 //BA.debugLineNum = 35;BA.debugLine="lblIP.text = server.GetMyIP()";
_lblip.setText(_server.GetMyIP());
 //BA.debugLineNum = 36;BA.debugLine="UpdateState(False)";
_updatestate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 37;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public static String  _astream_error() throws Exception{
 //BA.debugLineNum = 81;BA.debugLine="Sub AStream_Error";
 //BA.debugLineNum = 82;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 83;BA.debugLine="UpdateState(False)	'UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public static String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Sub AStream_Terminated";
 //BA.debugLineNum = 88;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 89;BA.debugLine="UpdateState(False)	'UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
String _strfilename = "";
String _strcurdir = "";
 //BA.debugLineNum = 100;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 103;BA.debugLine="Try";
try { //BA.debugLineNum = 104;BA.debugLine="Dim strFileName As String = \"screenshot-\" & Date";
_strfilename = "screenshot-"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.getNow())+".png";
 //BA.debugLineNum = 105;BA.debugLine="Dim strCurDir As String  = \"./\" 'this default to";
_strcurdir = "./";
 //BA.debugLineNum = 108;BA.debugLine="c3po.ScreenCurrentRectangleSetAsRightScreen '<-";
_c3po.ScreenCurrentRectangleSetAsRightScreen();
 //BA.debugLineNum = 109;BA.debugLine="c3po.ScreenCaptureToFile(strFileName)";
_c3po.ScreenCaptureToFile(_strfilename);
 //BA.debugLineNum = 111;BA.debugLine="Log( File.Exists(strCurDir,strFileName) )";
anywheresoftware.b4a.keywords.Common.LogImpl("1131083",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.File.Exists(_strcurdir,_strfilename)),0);
 //BA.debugLineNum = 113;BA.debugLine="SendData (c3po.ScreenCaptureAsByteArray)";
_senddata(_c3po.ScreenCaptureAsByteArray());
 //BA.debugLineNum = 115;BA.debugLine="ImageView1.setbitmap(BytesToImage(FileToBytes (s";
_imageview1.SetBitmap((javafx.scene.image.Image)(_bytestoimage(_filetobytes(_strcurdir,_strfilename)).getObject()));
 } 
       catch (Exception e10) {
			ba.setLastException(e10); //BA.debugLineNum = 117;BA.debugLine="Log(\"error\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1131089","error",0);
 };
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _bytestoimage(byte[] _bytes) throws Exception{
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _bmp = null;
 //BA.debugLineNum = 131;BA.debugLine="Public Sub BytesToImage(bytes() As Byte) As B4XBit";
 //BA.debugLineNum = 132;BA.debugLine="Dim In As InputStream";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 133;BA.debugLine="In.InitializeFromBytesArray(bytes, 0, bytes.Lengt";
_in.InitializeFromBytesArray(_bytes,(int) (0),_bytes.length);
 //BA.debugLineNum = 138;BA.debugLine="Dim bmp As Image";
_bmp = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 139;BA.debugLine="bmp.Initialize2(In)";
_bmp.Initialize2((java.io.InputStream)(_in.getObject()));
 //BA.debugLineNum = 141;BA.debugLine="Return bmp";
if (true) return (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (javafx.scene.image.Image)(_bmp.getObject()));
 //BA.debugLineNum = 142;BA.debugLine="End Sub";
return null;
}
public static byte[]  _filetobytes(String _dir,String _filename) throws Exception{
 //BA.debugLineNum = 127;BA.debugLine="Sub FileToBytes (Dir As String, FileName As String";
 //BA.debugLineNum = 128;BA.debugLine="Return Bit.InputStreamToBytes(File.OpenInput(Dir,";
if (true) return anywheresoftware.b4a.keywords.Common.Bit.InputStreamToBytes((java.io.InputStream)(anywheresoftware.b4a.keywords.Common.File.OpenInput(_dir,_filename).getObject()));
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return null;
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private c3po As AWTRobot";
_c3po = new butt.droid.awtRobot.AWTRobot();
 //BA.debugLineNum = 13;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private client As Socket";
_client = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private astream As AsyncStreams		'jRandomAccessFi";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 16;BA.debugLine="Private connected As Boolean";
_connected = false;
 //BA.debugLineNum = 18;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 20;BA.debugLine="Private lblIP As Label";
_lblip = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private lblstatus As Label";
_lblstatus = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private ImageView1 As B4XView";
_imageview1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public static String  _senddata(byte[] _data) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Public Sub SendData (data() As Byte)";
 //BA.debugLineNum = 77;BA.debugLine="If connected Then astream.Write(data)";
if (_connected) { 
_astream.Write(_data);};
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public static String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 41;BA.debugLine="Sub server_NewConnection(Successful As Boolean, Ne";
 //BA.debugLineNum = 43;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 44;BA.debugLine="client = NewSocket";
_client = _newsocket;
 //BA.debugLineNum = 47;BA.debugLine="astream.InitializePrefix(client.InputStream, Fal";
_astream.InitializePrefix(ba,_client.getInputStream(),anywheresoftware.b4a.keywords.Common.False,_client.getOutputStream(),"astream");
 //BA.debugLineNum = 48;BA.debugLine="UpdateState(True)		'成功的話.UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 50;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("11245193",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 54;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static String  _timer1_tick() throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Sub timer1_tick";
 //BA.debugLineNum = 94;BA.debugLine="Log(\"timer1_tick==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("12490369","timer1_tick==>",0);
 //BA.debugLineNum = 95;BA.debugLine="If connected Then Button1_Click";
if (_connected) { 
_button1_click();};
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public static String  _updatestate(boolean _newstate) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub UpdateState(NewState As Boolean)";
 //BA.debugLineNum = 59;BA.debugLine="If NewState Then";
if (_newstate) { 
 //BA.debugLineNum = 60;BA.debugLine="lblstatus.Text =\"連線\"";
_lblstatus.setText("連線");
 //BA.debugLineNum = 61;BA.debugLine="connected = True";
_connected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 62;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 65;BA.debugLine="lblstatus.Text =\"未連線\"";
_lblstatus.setText("未連線");
 //BA.debugLineNum = 66;BA.debugLine="connected = False";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 67;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
}
